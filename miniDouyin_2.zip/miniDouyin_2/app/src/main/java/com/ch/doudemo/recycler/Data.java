package com.ch.doudemo.recycler;

public class Data {
    public String username;
    public String message;
    public String dianzan;
    public String pinglun;

    public Data(String username, String message, String dianzan, String pinglun) {
        this.username = username;
        this.message = message;
        this.dianzan = dianzan;
        this.pinglun = pinglun;
    }
}
