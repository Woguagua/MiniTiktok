package com.ch.doudemo.base;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by ch
 * on 2017/12/19.15:42
 * 作用：
 */

public class BaseRecViewHolder extends RecyclerView.ViewHolder {
    public BaseRecViewHolder(View itemView) {
        super(itemView);
    }
}
